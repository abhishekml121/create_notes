# php-captcha
Learn how to create a PHP Captcha Script using the GD library with basic captcha validation to protect bot-generated mails or spam.

[PHP 7 Captcha Tutorial – Create Captcha in PHP Contact Form](https://www.positronx.io/create-captcha-in-php-contact-form/)